package com.example.mainactivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;




public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


    }





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mainmenu,menu);

        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent = new Intent(MainActivity.this, login.class);
        Intent intent2 = new Intent(MainActivity.this, RegisterActivity.class);
        switch(item.getItemId()){

            case R.id.register:
                startActivity(intent2);
                return true;
            case R.id.login:

                startActivity(intent);
                return true;

            case R.id.setting:
                Toast.makeText(getApplicationContext(),"설정 기능 준비중",Toast.LENGTH_LONG).show();
                return true;

            case R.id.review:
                Toast.makeText(getApplicationContext(),"후기 기능 준비중",Toast.LENGTH_LONG).show();
                return true;
            case R.id.community:
                Toast.makeText(getApplicationContext(),"커뮤니티 기능 준비중",Toast.LENGTH_LONG).show();

                return true;}
           return super.onOptionsItemSelected(item);



        }

    public void onClick(View view) {
        Intent intent3 = new Intent(MainActivity.this, Travel.class);
        switch (view.getId()) {
            case R.id.imageButton1:
                startActivity(intent3);
            break;
        }
    }
}
