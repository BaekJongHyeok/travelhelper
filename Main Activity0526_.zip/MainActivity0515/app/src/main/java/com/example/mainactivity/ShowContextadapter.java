package com.example.mainactivity;

import android.app.Activity;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ShowContextadapter extends RecyclerView.Adapter<ShowContextadapter.CustomViewHolder> {

    private ArrayList<ContextData> mList = null;
    private Activity context = null;
    private Context mContext;

    public ShowContextadapter(Activity context, ArrayList<ContextData> list) {
        this.context = context;
        this.mList = list;
        this.mContext = context;
    }

    class CustomViewHolder extends RecyclerView.ViewHolder {

        protected TextView context1;


        public CustomViewHolder(View view) {
            super(view);

            this.context1 = (TextView) view.findViewById(R.id.textView_list_context);

        }
    }


    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.contextitem, null);
        CustomViewHolder viewHolder = new CustomViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder viewholder, final int position) {


        viewholder.context1.setText(mList.get(position).getMember_context());


        //Click event


        viewholder.itemView.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {
                Context context = v.getContext();


            }
        });

    }

    @Override
    public int getItemCount() {
        return (null != mList ? mList.size() : 0);
    }

}