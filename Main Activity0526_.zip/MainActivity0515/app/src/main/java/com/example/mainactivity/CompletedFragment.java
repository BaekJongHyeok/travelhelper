package com.example.mainactivity;

import android.content.Context;
import android.graphics.Paint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class CompletedFragment extends Fragment {
    public static ArrayList<Item3> items = new ArrayList<>();
    public static MyAdapter2 adapter;
    public String key = "%2Bnv760op%2BarsgrvnuO9HN49TLg%2Fy2IceS%2B0uZw2kJbxTkpZud5jpAn4f2gvTTI6RIasycoqjesa2AwJ3NWsslQ%3D%3D";
    private String requestUrl;
    ArrayList<Item3> list = null;
    Item3 bus = null;
    RecyclerView recyclerView;
    public String contentid;
    public String Service_Country="KorService";
    public CompletedFragment () {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_one, container, false);

        recyclerView = (RecyclerView) rootView.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);



        com.example.mainactivity.CompletedFragment.MyAsyncTask myAsyncTask = new com.example.mainactivity.CompletedFragment.MyAsyncTask();
        myAsyncTask.execute();

        return rootView;
    }

    public class MyAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {

            contentid=((M2)getActivity()).publicMethod();


            String requestUrl="http://api.visitkorea.or.kr/openapi/service/rest/"+Service_Country+"/detailCommon?"
                    +"&serviceKey="+key
                    +"&numOfRows=10&pageNo=1&MobileOS=ETC&MobileApp=AppTest&contentTypeId=&defaultYN=Y&firstImageYN=Y&areacodeYN=Y&catcodeYN=Y&addrinfoYN=Y&mapinfoYN=Y&overviewYN=Y"

                    +"&contentId="+contentid;


            try {
                boolean b_locationNo1 = false;
                boolean b_plateNo1 = false;
                boolean b_routeId = false;
                boolean b_stationId = false;

                URL url = new URL(requestUrl);
                InputStream is = url.openStream();
                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                XmlPullParser parser = factory.newPullParser();
                parser.setInput(new InputStreamReader(is, "UTF-8"));

                String tag;
                int eventType = parser.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT) {
                    switch (eventType) {
                        case XmlPullParser.START_DOCUMENT:
                            list = new ArrayList<Item3>();
                            break;
                        case XmlPullParser.END_DOCUMENT:
                            break;
                        case XmlPullParser.END_TAG:
                            if (parser.getName().equals("item") && bus != null) {
                                list.add(bus);
                            }
                            break;
                        case XmlPullParser.START_TAG:
                            if (parser.getName().equals("item")) {
                                bus = new Item3();
                            }
                            if (parser.getName().equals("addr1")) b_locationNo1 = true;
                            if (parser.getName().equals("title")) b_plateNo1 = true;
                            if (parser.getName().equals("firstimage")) b_routeId = true;
                            if (parser.getName().equals("overview")) b_stationId = true;
                            break;
                        case XmlPullParser.TEXT:
                            if (b_locationNo1) {
                                bus.setLocationNo1(parser.getText());
                                b_locationNo1 = false;
                            } else if (b_plateNo1) {
                                bus.setPlateNo1(parser.getText());
                                b_plateNo1 = false;
                            } else if (b_routeId) {
                                bus.setRouteId(parser.getText());
                                b_routeId = false;
                            } else if (b_stationId) {
                                bus.setStationId(parser.getText());
                                b_stationId = false;
                            }
                            break;
                        default:
                            throw new IllegalStateException("Unexpected value: " + eventType);
                    }
                    eventType = parser.next();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            MyAdapter2 adapter = new MyAdapter2(getContext(), list);
            recyclerView.setAdapter(adapter);
            //어답터 연결
        }
    }

}


/* public String contentid;
    public String key = "%2Bnv760op%2BarsgrvnuO9HN49TLg%2Fy2IceS%2B0uZw2kJbxTkpZud5jpAn4f2gvTTI6RIasycoqjesa2AwJ3NWsslQ%3D%3D";
    private String requestUrl;
    ArrayList<Item3> list = null;
    Item3 bus = null;
    RecyclerView recyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);



        setContentView(R.layout.activity_m2);
        Intent intent = getIntent();
        String contentid2 =intent.getStringExtra("a");
        contentid= contentid2;
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);


//        AsyncTask
        com.example.mainactivity.M2.MyAsyncTask myAsyncTask = new com.example.mainactivity.M2.MyAsyncTask();
        myAsyncTask.execute();



    }







    public class MyAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {



            String requestUrl="http://api.visitkorea.or.kr/openapi/service/rest/KorService/detailCommon?"
                    +"&serviceKey="+key
                    +"&numOfRows=10&pageNo=1&MobileOS=ETC&MobileApp=AppTest&contentTypeId=&defaultYN=Y&firstImageYN=Y&areacodeYN=Y&catcodeYN=Y&addrinfoYN=Y&mapinfoYN=Y&overviewYN=Y"

                    +"&contentId="+contentid;


            try {
                boolean b_locationNo1 = false;
                boolean b_plateNo1 = false;
                boolean b_routeId = false;
                boolean b_stationId = false;

                URL url = new URL(requestUrl);
                InputStream is = url.openStream();
                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                XmlPullParser parser = factory.newPullParser();
                parser.setInput(new InputStreamReader(is, "UTF-8"));

                String tag;
                int eventType = parser.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT) {
                    switch (eventType) {
                        case XmlPullParser.START_DOCUMENT:
                            list = new ArrayList<Item3>();
                            break;
                        case XmlPullParser.END_DOCUMENT:
                            break;
                        case XmlPullParser.END_TAG:
                            if (parser.getName().equals("item") && bus != null) {
                                list.add(bus);
                            }
                            break;
                        case XmlPullParser.START_TAG:
                            if (parser.getName().equals("item")) {
                                bus = new Item3();
                            }
                            if (parser.getName().equals("addr1")) b_locationNo1 = true;
                            if (parser.getName().equals("title")) b_plateNo1 = true;
                            if (parser.getName().equals("firstimage")) b_routeId = true;
                            if (parser.getName().equals("overview")) b_stationId = true;
                            break;
                        case XmlPullParser.TEXT:
                            if (b_locationNo1) {
                                bus.setLocationNo1(parser.getText());
                                b_locationNo1 = false;
                            } else if (b_plateNo1) {
                                bus.setPlateNo1(parser.getText());
                                b_plateNo1 = false;
                            } else if (b_routeId) {
                                bus.setRouteId(parser.getText());
                                b_routeId = false;
                            } else if (b_stationId) {
                                bus.setStationId(parser.getText());
                                b_stationId = false;
                            }
                            break;
                        default:
                            throw new IllegalStateException("Unexpected value: " + eventType);
                    }
                    eventType = parser.next();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            //어답터 연결
            MyAdapter2 adapter = new MyAdapter2(getApplicationContext(), list);
            recyclerView.setAdapter(adapter);
        }
    }
}
*/