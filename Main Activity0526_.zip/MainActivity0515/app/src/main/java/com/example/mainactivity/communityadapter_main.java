package com.example.mainactivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class communityadapter_main extends RecyclerView.Adapter<communityadapter_main.CustomViewHolder> {

    private ArrayList<communityData> mList = null;
    private Activity context = null;
    String text;
    private Context mContext;

    public communityadapter_main(Activity context, ArrayList<communityData> list) {
        this.context = context;
        this.mList = list;
        this.mContext = context;
    }

    class CustomViewHolder extends RecyclerView.ViewHolder {
        protected TextView row_number;
        protected TextView title;
        protected TextView Date;


        public CustomViewHolder(View view) {
            super(view);
            this.row_number = (TextView) view.findViewById(R.id.textView_list_row_number);
            this.title = (TextView) view.findViewById(R.id.textView_list_title);
            this.Date = (TextView) view.findViewById(R.id.textView_list_Date);
        }
    }


    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.communityitem, null);
        CustomViewHolder viewHolder = new CustomViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder viewholder, final int position) {

        viewholder.row_number.setText(mList.get(position).getMember_row_number());
        viewholder.title.setText(mList.get(position).getMember_title());
        viewholder.Date.setText(mList.get(position).getMember_Date());

        //Click event


        viewholder.itemView.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {
                Context context = v.getContext();
                text = mList.get(position).member_address;


               Intent intent = new Intent(mContext, Maincommunity.class);
               intent.setFlags(intent.FLAG_ACTIVITY_NEW_TASK);
              //  intent.putExtra("a",mList.get(position).getMember_row_number());

                mContext.startActivity(intent);

            }
        });

    }
    @Override
    public int getItemCount() {
        return (null != mList ? mList.size() : 0);
    }

}