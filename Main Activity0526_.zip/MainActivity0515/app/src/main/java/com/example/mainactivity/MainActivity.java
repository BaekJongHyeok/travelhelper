package com.example.mainactivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;

import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;


import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    SharedPreferences sharedPreferences;

    private static String TAG = "phptest";

    private EditText mEditTexttitle;
    private EditText mEditTextDate;
    private EditText mEditTextSearchKeyword;

    private ArrayList<communityData> mArrayList;
    private communityadapter_main mAdapter;
    private RecyclerView mRecyclerView_main;
    private String mJsonString;
    private String mTextViewResult;

    private void getHashKey(){
        PackageInfo packageInfo = null;
        try {
            packageInfo = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        if (packageInfo == null)
            Log.e("KeyHash", "KeyHash:null");

        for (Signature signature : packageInfo.signatures) {
            try {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.d("KeyHash", Base64.encodeToString(md.digest(), Base64.DEFAULT));
            } catch (NoSuchAlgorithmException e) {
                Log.e("KeyHash", "Unable to get MessageDigest. signature=" + signature, e);
            }
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main2);
        sharedPreferences = getSharedPreferences("UserInfo", Context.MODE_PRIVATE);

    mRecyclerView_main = (RecyclerView) findViewById(R.id.listView_main_list);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);

        mLayoutManager.setReverseLayout(true);
        mLayoutManager.setStackFromEnd(true);

        mRecyclerView_main.setLayoutManager(mLayoutManager);


    mArrayList = new ArrayList<>();

    mAdapter = new communityadapter_main(this, mArrayList);
        mRecyclerView_main.setAdapter(mAdapter);

        mArrayList.clear();
        mAdapter.notifyDataSetChanged();

    MainActivity.GetData task = new MainActivity.GetData();
        task.execute( "http://ahtj1234.dothome.co.kr/Community.php", "");


    }






    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mainmenu,menu);




        return true;
    }


    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {


        String loginStatus = sharedPreferences.getString(getResources().getString(R.string.prefLoginState), "");
        if (loginStatus.equals("loggedin")) {
            menu.getItem(3).setEnabled(true);
            menu.getItem(2).setEnabled(false);
        }else{ // 로그 아웃 한 상태 : 로그인 보이게, 로그아웃은 안보이게
            menu.getItem(3).setEnabled(false);
            menu.getItem(2).setEnabled(true);
        }



        return super.onPrepareOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent = new Intent(MainActivity.this, login.class);
        Intent intent4 = new Intent(MainActivity.this, Maincommunity.class);
        Intent intent2 = new Intent(MainActivity.this, RegisterActivity.class);
        switch(item.getItemId()){

            case R.id.register:
                startActivity(intent2);
                return true;
            case R.id.login:

                startActivity(intent);
                return true;

            case R.id.setting:
                Toast.makeText(getApplicationContext(),"설정 기능 준비중",Toast.LENGTH_LONG).show();
                return true;


            case R.id.community:
                //Toast.makeText(getApplicationContext(),"커뮤니티 기능 준비중",Toast.LENGTH_LONG).show();
                startActivity(intent4);
                return true;
            case R.id.logout:

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(getResources().getString(R.string.prefLoginState), "loggedout");
                editor.apply();
                return true;
            case R.id.search_travel:
                Intent intent3 = new Intent(MainActivity.this, Travel.class);
                startActivity(intent3);
                return true;
        }
           return super.onOptionsItemSelected(item);



        }


    private class GetData extends AsyncTask<String, Void, String> {

        ProgressDialog progressDialog;
        String errorString = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = ProgressDialog.show(MainActivity.this,
                    "Please Wait", null, true, true);
        }


        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            mTextViewResult=(result);
            Log.d(TAG, "response - " + result);

            if (result == null){

                Toast.makeText(MainActivity.this, errorString, Toast.LENGTH_SHORT).show();
            }
            else {

                mJsonString = result;
                showResult();
            }
        }


        @Override
        protected String doInBackground(String... params) {

            String serverURL = params[0];
            String postParameters = params[1];


            try {

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();


                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();


                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }


                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }

                bufferedReader.close();

                return sb.toString().trim();


            } catch (Exception e) {

                Log.d(TAG, "GetData : Error ", e);
                errorString = e.toString();

                return null;
            }

        }
    }


    private void showResult(){

        String TAG_JSON="webnautes";
        String TAG_row_number = "row_number";
        String TAG_title = "title";
        String TAG_Date ="date";


        try {
            JSONObject jsonObject = new JSONObject(mJsonString);
            JSONArray jsonArray = jsonObject.getJSONArray(TAG_JSON);

            for(int i=0;i<jsonArray.length();i++){

                JSONObject item = jsonArray.getJSONObject(i);

                String row_number = item.getString(TAG_row_number);
                String title = item.getString(TAG_title);
                String Date = item.getString(TAG_Date);


                communityData personalData = new communityData();

                personalData.setMember_row_number(row_number);
                personalData.setMember_title(title);
                personalData.setMember_Date(Date);



                mArrayList.add(personalData);
                mAdapter.notifyDataSetChanged();
            }



        } catch (JSONException e) {

            Log.d(TAG, "showResult : ", e);
        }

    }


}



