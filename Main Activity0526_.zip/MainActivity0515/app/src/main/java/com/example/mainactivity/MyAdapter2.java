package com.example.mainactivity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
public class MyAdapter2 extends RecyclerView.Adapter<MyAdapter2.MyViewHolder> {
    String contentid;
    private ArrayList<Item3> mList;
    private LayoutInflater mInflate;
    private Context mContext;

    public MyAdapter2(Context context, ArrayList<Item3> itmes) {
        this.mList = itmes;
        this.mInflate = LayoutInflater.from(context);
        this.mContext = context;
    }


    @NonNull
    @Override
    public MyAdapter2.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflate.inflate(R.layout.item3, parent, false);
        MyAdapter2.MyViewHolder viewHolder = new MyAdapter2.MyViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter2.MyViewHolder holder, final int position) {
        //binding
        holder.locationNo1.setText(mList.get(position).locationNo1);
        holder.plateNo1.setText(mList.get(position).plateNo1);
        holder.stationId.setText(mList.get(position).stationId);

        //Click event


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    //ViewHolder
    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView locationNo1;
        public TextView plateNo1;
        public TextView routeId;
        public TextView stationId;

        public MyViewHolder(View itemView) {
            super(itemView);

            locationNo1 = itemView.findViewById(R.id.tv_locationNo1);
            plateNo1 = itemView.findViewById(R.id.tv_plateNo1);
            stationId = itemView.findViewById(R.id.tv_stationId);

        }
    }

}
