package com.example.mainactivity;

public class ContextData {

    private String member_context;





    public String getMember_context(){
        return member_context;
    }




    public void setMember_context(String member_context) {
        this.member_context = member_context;
    }

}
