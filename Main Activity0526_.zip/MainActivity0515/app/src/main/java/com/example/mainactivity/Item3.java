package com.example.mainactivity;

public class Item3 {
    String locationNo1;
    String locationNo2;
    String plateNo1;
    String predictTime1;
    String predictTime2;
    String routeId;
    String staOrder;
    String stationId;


    public String getLocationNo1() {
        return locationNo1;
    }

    public String getLocationNo2() {
        return locationNo2;
    }

    public String getPlateNo1() {
        return plateNo1;
    }

    public String getPredictTime1() {
        return predictTime1;
    }

    public String getPredictTime2() {
        return predictTime2;
    }

    public String getRouteId() {
        return routeId;
    }

    public String getStaOrder() {
        return staOrder;
    }

    public String getStationId() {
        return stationId;
    }

    public void setLocationNo1(String locationNo1) {
        this.locationNo1 = locationNo1;
    }

    public void setLocationNo2(String getLocationNo2) {
        this.locationNo2 = getLocationNo2;
    }

    public void setPlateNo1(String plateNo1) {
        this.plateNo1 = plateNo1;
    }

    public void setPredictTime1(String predictTime1) {
        this.predictTime1 = predictTime1;
    }

    public void setPredictTime2(String predictTime2) {
        this.predictTime2 = predictTime2;
    }

    public void setRouteId(String routeId) {
        this.routeId = routeId;
    }

    public void setStaOrder(String staOrder) {
        this.staOrder = staOrder;
    }

    public void setStationId(String stationId) {
        this.stationId = stationId;
    }
}
