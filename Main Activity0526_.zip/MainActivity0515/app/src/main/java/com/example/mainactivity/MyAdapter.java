package com.example.mainactivity;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<com.example.mainactivity.MyAdapter.MyViewHolder> {
    String contentid;
    String mapx;
    String mapy;
    private ArrayList<Item> mList;
    private LayoutInflater mInflate;
    private Context mContext;

    public MyAdapter(Context context, ArrayList<Item> itmes) {
        this.mList = itmes;
        this.mInflate = LayoutInflater.from(context);
        this.mContext = context;
    }


    @NonNull
    @Override
    public com.example.mainactivity.MyAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflate.inflate(R.layout.item, parent, false);
        com.example.mainactivity.MyAdapter.MyViewHolder viewHolder = new com.example.mainactivity.MyAdapter.MyViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull com.example.mainactivity.MyAdapter.MyViewHolder holder, final int position) {
        //binding

        holder.plateNo1.setText(mList.get(position).plateNo1);



        //Click event


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context = v.getContext();

                contentid = mList.get(position).routeId;
                mapx = mList.get(position).mapx;
                mapy = mList.get(position).mapy;
                Intent intent = new Intent(mContext, M2.class);
                intent.setFlags(intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("a",contentid);
                intent.putExtra("b",mapx);
                intent.putExtra("c",mapy);
                mContext.startActivity(intent);
                //Toast.makeText(context,position +"/"+contentid, Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    //ViewHolder
    public static class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView plateNo1;



        public MyViewHolder(View itemView) {
            super(itemView);

            plateNo1 = itemView.findViewById(R.id.travel_title);


        }
    }
}