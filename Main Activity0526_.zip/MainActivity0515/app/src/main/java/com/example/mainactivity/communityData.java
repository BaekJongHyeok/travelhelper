package com.example.mainactivity;

public class communityData {
    private String member_row_number;
    private String member_title;
    private String member_Date;

    String member_address;
    public String getMember_row_number(){
        return member_row_number;
    }

    public String getMember_title(){
        return member_title;
    }

    public String getMember_Date(){
        return member_Date;
    }

    public void setMember_row_number(String member_row_number) {
        this.member_row_number = member_row_number;
    }

    public void setMember_title(String member_title) {
        this.member_title = member_title;
    }

    public void setMember_Date(String member_address) {
        this.member_Date = member_address;
    }

}
