package com.example.mainactivity;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import net.daum.mf.map.api.MapPOIItem;
import net.daum.mf.map.api.MapPoint;
import net.daum.mf.map.api.MapView;

import androidx.fragment.app.Fragment;


public class Fragment_map extends Fragment {
    public double mapx;
    public double mapy;


    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_map, container, false);

        mapx = ((M2) getActivity()).publicMethod2();
        mapy = ((M2) getActivity()).publicMethod3();


      // double d_mapx = Double.valueOf(mapx);
       // double d_mapy = Double.valueOf(mapy);
        MapView mapView = new MapView(getActivity());
        ViewGroup mapViewContainer = (ViewGroup) v.findViewById(R.id.map_view);
        mapViewContainer.addView(mapView);

        // 중심점 변경 - 예제 좌표는 서울 남산

        mapView.setDaumMapApiKey("2f1148e460b2b3c775a295badc75299b");

        MapPoint mapPoint = MapPoint.mapPointWithGeoCoord(mapy, mapx);
        mapView.setMapCenterPoint(mapPoint, true);
        //true면 앱 실행 시 애니메이션 효과가 나오고 false면 애니메이션이 나오지않음.
       // Toast.makeText(getContext(),mapy + "/ " + mapx, Toast.LENGTH_LONG).show();

        MapPOIItem marker = new MapPOIItem();
        marker.setItemName("관광지");
        marker.setTag(0);
        marker.setMapPoint(mapPoint);
        // 기본으로 제공하는 BluePin 마커 모양.
        marker.setMarkerType(MapPOIItem.MarkerType.BluePin);
        // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.
        marker.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin);
        mapView.addPOIItem(marker);

        return v;

    }


    private void initDataset() {

        // 줌 레벨 변경
        //mapView.setZoomLevel(4, true);


    }

}




